# Cara Gallagher
# updated April 19th, 2020
# Porpoise Energy Budget evaluation outputs
# Using data from Kinze & Galatius (unps) and Rojano-Doñate et al. 2018
# Figure 3 in Gallagher et al. (submitted)
# See TRACE section 8 for details

library(tidyverse)
library(wesanderson)


evaluationData <- read_csv("data/EvaluationSeasonalOutputs.csv") 

############## Seasonal blubber depth #############

# filter out blubber depth data from model outputs and calculate mean & standard deviations for each month
blubberDepth <- 
  evaluationData %>% 
   filter(metric == "BlubDepth") %>% 
   rename(L4cm = mean, L4cmsd = sd) %>% 
   mutate(L4cmhi = L4cm + L4cmsd, L4cmlo = L4cm - L4cmsd)

# load empirical estimates of blubber depth at site L4 from Kinze & Galatius (unps)
blubberDepthEmpirical <- read_csv("data/EvaluationPorpoiseBlubberData.csv")                   

############## Seasonal total metabolic costs (for non-lactating animals) #############

# filter out total metabolism data from model outputs and calculate mean & standard deviations for each month
fieldMetabolicRate <-
  evaluationData %>%
  filter(metric == "MTot") %>% 
  rename(FMRm = mean, FMRsd = sd) %>%
  mutate(FMRhi = FMRm + FMRsd, FMRlo = FMRm - FMRsd) 

# load empirical estimates for all wild and all captive individuals in Rojano-Doñate et al. 2018
fieldMetabolicRateEmpirical <- tibble( 
  dat = c("Captive", "Wild"),
  yint = c(18.2, 15.5)
)

############## Seasonal total energy intake (for non-lactating animals) #############

# filter out total energy intake data from model outputs and calculate mean & standard deviations for each month
energyIntake <- 
  evaluationData %>% 
  filter(metric == "Food") %>% 
  rename(EImean = mean, EIsd = sd) %>% 
  mutate(EIhi = EImean + EIsd, EIlo = EImean - EIsd)

# load empirical estimates for captive individuals in Rojano-Doñate et al. 2018
energyIntakeEmpirical <- tibble( 
  dat = c("min", "max"),
  yint = c(15.5, 31.3)
)


################ Create plots ######################


pal <- wes_palette("Zissou1", 6, type = "continuous") # pull colors from wes anderson palette

# plot: blubber thickness at site L4
ggplot() + 
  geom_violin(data=blubberDepthEmpirical, aes(x = factor(month), y = L4cm), col = pal[1]) + 
  geom_boxplot(data=blubberDepthEmpirical, aes(x = factor(month), y = L4cm),width=0.1, col = pal[1], fill = pal[2], alpha = 0.75) +
  geom_ribbon(data=blubberDepth, aes(x = month, ymax =  predict(loess(L4cmhi ~ month, span = 0.5)), ymin = predict(loess(L4cmlo ~ month, span = 0.5))), fill = pal[6], alpha = 0.25) +
  geom_smooth(data=blubberDepth, aes(x = month, y = L4cm), col = pal[6], fill = pal[6], size = 1.25,  method = "loess", span = 0.55, level = 0.95, se = FALSE) +
  theme_classic() + ylab("Blubber depth [cm]") + xlab("Month") +
  ylim(0.3,5.25) +
  geom_text(data=blubberDepthEmpirical, aes(x = month, y = maxL4, label = n), col = pal[1],  nudge_y = 0.15) +
  theme(text = element_text(size = 11, color = "gray40", face = "bold"),
        legend.position = "none",
        plot.margin=unit(c(0.25,0.25,-0.1,0.25),"cm"),
        axis.text = element_text(size = 10, color = "gray40", face = "bold"),
        axis.title = element_text(size = 13, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))

# plot: seasonal total metabolic rate for non-lactating animals
ggplot() +
  geom_smooth(data=fieldMetabolicRate, aes(x = month, y = FMRm), col = pal[6], fill = pal[6], size = 1.25,  method = "loess", span = 0.5, level = 0.95, se = FALSE) +
  geom_ribbon(data=fieldMetabolicRate, aes(x = month, ymax =  predict(loess(FMRhi ~ month, span = 0.5)), ymin = predict(loess(FMRlo ~ month, span = 0.5))), fill = pal[6], alpha = 0.25) +
  geom_hline(data = fieldMetabolicRateEmpirical, aes(yintercept = yint, linetype = dat), col = pal[1], size = 1.25) +
  theme_classic() +  coord_cartesian(ylim=c(11,21)) +   
  labs(x = "Month", y = bquote(bold("Field metabolic rate [MJ day"^-1*"]"))) +
  scale_linetype_manual(values = c("solid", "dotdash"))+ 
  scale_x_continuous(breaks = 1:12,labels = 1:12) +
  theme(text = element_text(size = 11, color = "gray40", face = "bold"),
        legend.position=c(0.5,0.07),
        legend.direction = "horizontal",
        legend.title = element_blank(),
        legend.background = element_blank(),
        legend.key.size = unit(0.5, "cm"),
        legend.key.width = unit(1.5,"cm") ,
        legend.text = element_text(size = 10, color = "gray40", face = "bold"),
        plot.margin=unit(c(0.25,0.25,-0.1,0.25),"cm"),
        axis.text = element_text(size = 10, color = "gray40", face = "bold"),
        axis.title = element_text(size = 13, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))+
  guides(guide_legend(label.vjust = 5))


# plot: seasonal energy intake for non-lactating animals
ggplot(data=energyIntake, aes(x = month)) +  
  geom_ribbon(aes(ymax =  energyIntakeEmpirical$yint[2], ymin = energyIntakeEmpirical$yint[1]), fill = pal[1], alpha = 0.25) +
  geom_hline(yintercept = energyIntakeEmpirical$yint[1], col = pal[1],  size = 1.25, alpha = 0.75) +
  geom_hline(yintercept = energyIntakeEmpirical$yint[2], col = pal[1], size = 1.25, alpha = 0.75) +
  geom_smooth(aes(y = EImean),col = pal[6], size = 1.25,  method = "loess", span = 0.5, se = FALSE) +
  geom_ribbon(data=energyIntake, aes(x = month, ymax =  predict(loess(EIhi ~ month, span = 0.5)), ymin = predict(loess(EIlo ~ month, span = 0.5))), fill = pal[6], alpha = 0.25) +
  theme_classic() + coord_cartesian(ylim=c(5,38)) +
  scale_x_continuous(breaks = 1:12,labels = month.abb) +
  labs(x = NULL, y = bquote(bold("Energy intake [MJ day"^-1*"]"))) +
  theme(text = element_text(size = 11, color = "gray40", face = "bold"),
        legend.position = "none",
        plot.margin=unit(c(0.25,0.25,0.25,0.25),"cm"),
        axis.text = element_text(size = 10, color = "gray40", face = "bold"),
        axis.title = element_text(size = 13, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))
