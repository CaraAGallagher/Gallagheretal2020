# Cara Gallagher
# updated April 19th, 2020
# Porpoise Energy Budget Scenario Outputs
# Scenario: Three seismic survey vessels operating simultaneously in IDW
# Figure 6 in Gallagher et al. (submitted)
# See main text for details

library(tidyverse)
library(wesanderson)

# load RData file
load(file = "data/ScenarioExposureOutputs.RData")


############## Local abundance outputs ############## 

localAbundanceRef <- localAbundanceOutputs %>%  # reference run outputs
  filter(metric == "LocalAbundanceRef")

localAbundanceExp <- localAbundanceOutputs %>% # exposure run outputs
  filter(metric == "LocalAbundance")


# calculating deviance values in the reference runs
localAbundanceRef <- localAbundanceRef %>% 
  group_by(month, runNumber) %>% 
  filter(year >= minYear & year < maxYear) %>%                # filtering by exposure period
  mutate(count = count - count[1],                            # standarizing by setting start to zero
         countRef = countRef - countRef[1],
         diff = count - countRef) %>% 
  filter(diff == min(diff)) %>%                               # finding the largest drop in abundance 
  distinct(runNumber,diff,.keep_all = TRUE)

# calculating the mean and standard deviation of deviation values per month
maxDevLocAbunRef <- localAbundanceRef %>% 
  ungroup() %>% 
  select(runNumber, diff, month) %>% 
  group_by(month) %>% 
  summarise(meanRef = mean(diff), sdRef = sd(diff))

# calculating deviance values in the exposure runs
localAbundanceExp <- localAbundanceExp %>% 
  group_by(month, runNumber) %>% 
  filter(year >= minYear & year < maxYear) %>%                # filtering by exposure period
  mutate(count = count - count[1],                            # standarizing by setting start to zero
         countRef = countRef - countRef[1],
         diff = count - countRef) %>% 
  filter(diff == min(diff)) %>%                               # finding the largest drop in abundance 
  distinct(runNumber,diff,.keep_all = TRUE) %>%              
  mutate(group = ifelse(runNumber <= 20, 1, ifelse(runNumber <= 40, 2, ifelse(runNumber <= 60, 3, ifelse(runNumber <= 80, 4, 5)))))  # grouping exposure runs into five groups

# calculating the mean and standard deviation of deviation values per month
maxDevLocAbunExp <- localAbundanceExp %>% 
  ungroup() %>% 
  select(runNumber, month, diff, group) %>% 
  group_by(month, group) %>% 
  summarise(mean = mean(diff), sd = sd(diff))

# join for Hedge's calculation
totLocalAbundance <- left_join(maxDevLocAbunExp, maxDevLocAbunRef, by = "month")

hedgesLocalAbundance <- totLocalAbundance %>% 
  ungroup() %>% 
  group_by(month) %>% 
  mutate(SDpool = sqrt((((100-1)*sdRef^2) + ((20-1)*sd^2))/(100+20-2))) %>%  # pooled standard deviation
  mutate(g = ((meanRef - mean)/SDpool)*(1-(3/(4*(100+20)-9)))) %>%           # Hedge's g
  summarise(gmean = mean(g), gsd = sd(g)) %>%                                # average and standard deviation of g per month
  mutate(month = factor(month.abb[month], levels = month.abb)) %>% 
  mutate(col = ifelse(gmean < 0.20, 1, ifelse(gmean < 0.50, 2, ifelse(gmean < 0.80, 3, 4)))) # setting colors for plots based on g value


############## Storage level outputs ############## 

# calculating deviance values in the reference runs
storageLevelRef <- storageLevelOutputs %>% 
  group_by(runNumber, month) %>% 
  filter(sourceLevel == 0) %>% 
  mutate(storageLev = storageLev - storageLev[1],               # standarizing by setting start to zero         
         storageLevRef = storageLevRef - storageLevRef[1],
         diff = storageLev - storageLevRef) %>%  
  filter(diff == min(diff, na.rm = TRUE))                       # finding the largest drop in storage level 

# calculating the mean and standard deviation of deviation values per month
maxDevStorageLevRef <- storageLevelRef %>% 
  ungroup() %>% 
  select(runNumber, diff, month) %>% 
  group_by(month) %>% 
  summarise(meanRef = mean(diff), sdRef = sd(diff))

# calculating deviance values in the exposure runs
storageLevelExp <- storageLevelOutputs %>% 
  group_by(runNumber, month) %>% 
  filter(sourceLevel != 0) %>% 
  mutate(storageLev = storageLev - storageLev[1],                 # standarizing by setting start to zero    
         storageLevRef = storageLevRef - storageLevRef[1],
         diff = storageLev - storageLevRef) %>% 
  filter(diff == min(diff, na.rm = TRUE)) %>%                     # finding the largest drop in storage level 
  mutate(group = ifelse(runNumber <= 20, 1, ifelse(runNumber <= 40, 2, ifelse(runNumber <= 60, 3, ifelse(runNumber <= 80, 4, 5))))) # setting colors for plots based on g value


# calculating the mean and standard deviation of deviation values per month
maxDevStorageLevExp <- storageLevelExp %>% 
  ungroup() %>% 
  select(runNumber, month, diff, group) %>% 
  group_by(month,group) %>% 
  summarise(mean = mean(diff), sd = sd(diff))



# join for Hedge's calculation
totStorageLevel <- left_join(maxDevStorageLevExp, maxDevStorageLevRef, by = c("month"))

hedgesStorageLevel <- totStorageLevel %>% 
  ungroup() %>% 
  group_by(month) %>% 
  mutate(SDpool = sqrt((((100-1)*sdRef^2) + ((20-1)*sd^2))/(100+20-2))) %>%  # pooled standard deviation
  mutate(g = ((meanRef - mean)/SDpool)*(1-(3/(4*(100+20)-9)))) %>%           # Hedge's g
  summarise(gmean = mean(g), gsd = sd(g)) %>%                                # average and standard deviation of g per month
  mutate(month = factor(month.abb[month], levels = month.abb)) %>% 
  mutate(col = ifelse(gmean < 0.20, 1, ifelse(gmean < 0.50, 2, ifelse(gmean < 0.80, 3, 4)))) # setting colors for plots based on g value


############## Total calf loss outputs ############## 

hedgesTotalCalfLoss <- totalCalfLossOutputs %>% 
  filter(sourceLevel != 0) %>% 
  mutate(group = ifelse(runNumber <= 20, 1, ifelse(runNumber <= 40, 2, ifelse(runNumber <= 60, 3, ifelse(runNumber <= 80, 4, 5))))) %>% # grouping exposure runs into five groups
  group_by(month, group) %>% 
  summarise(TCL = mean(totCalfLoss, na.rm = TRUE), TCLsd = sd(totCalfLoss, na.rm = TRUE)) %>%                           # exposure mean and standard deviation per month
  mutate(TCLRef = totalCalfLossOutputs$totCalfLossRefMean[1], TCLRefsd = totalCalfLossOutputs$totCalfLossRefSD[1]) %>%  # reference values
  mutate(SDpool = sqrt((((100-1)*TCLRefsd^2) + ((20-1)*TCLsd^2))/(100+20-2))) %>%                                       # pooled standard deviation
  mutate(g = ((TCL - TCLRef)/SDpool)*(1-(3/(4*(100+20)-9)))) %>%                                                        # Hedge's g
  summarise(gmean = mean(g), gsd = sd(g)) %>%                                                                           # average and standard deviation of g per month
  mutate(month = factor(month.abb[month], levels = month.abb)) %>% 
  mutate(col = ifelse(gmean < 0.20, 1, ifelse(gmean < 0.50, 2, ifelse(gmean < 0.80, 3, 4)))) # setting colors for plots based on g value



############## Calf mass outputs ############## 

# calculating deviance values in the reference runs
calfMassRef <- calfMassOutputs %>%
  group_by(runNumber, month) %>%
  filter(sourceLevel == 0) %>%
  mutate(calfMass = calfMass - calfMass[1],               # standarizing by setting start to zero         
         calfMassRef = calfMassRef - calfMassRef[1],
         diff = calfMass - calfMassRef) %>%               
  filter(diff == min(diff, na.rm = TRUE))                 # finding the largest drop in calf mass

# calculating the mean and standard deviation of deviation values per month
maxDevCalfMassRef <- calfMassRef %>%
  ungroup() %>%
  select(runNumber, diff, month) %>%
  group_by(month) %>%
  summarise(meanRef = mean(diff), sdRef = sd(diff)) 


# calculating deviance values in the exposure runs
calfMassExp <- calfMassOutputs %>%
  group_by(runNumber, month) %>%
  filter(sourceLevel != 0) %>%
  mutate(calfMass = calfMass - calfMass[1],               # standarizing by setting start to zero     
         calfMassRef = calfMassRef - calfMassRef[1],
         diff = calfMass - calfMassRef) %>%
  filter(diff == min(diff, na.rm = TRUE)) %>%             # finding the largest drop in calf mass
  mutate(group = ifelse(runNumber <= 20, 1, ifelse(runNumber <= 40, 2, ifelse(runNumber <= 60, 3, ifelse(runNumber <= 80, 4, 5))))) # setting colors for plots based on g value

# calculating the mean and standard deviation of deviation values per month
maxDevCalfMassExp <- calfMassExp %>%
  ungroup() %>%
  select(runNumber, diff, group,  month) %>%
  group_by(group, month) %>%
  summarise(mean = mean(diff), sd = sd(diff))


# join for Hedge's calculation
totCalfMass <- left_join(maxDevCalfMassExp, maxDevCalfMassRef, by = c("month"))

hedgesCalfMass <- totCalfMass %>%
  ungroup() %>% 
  group_by(month) %>% 
  mutate(SDpool = sqrt((((100-1)*sdRef^2) + ((20-1)*sd^2))/(100+20-2))) %>%  # pooled standard deviation
  mutate(g = ((meanRef - mean)/SDpool)*(1-(3/(4*(100+20)-9)))) %>%           # Hedge's g
  summarise(gmean = mean(g), gsd = sd(g)) %>%                                # average and standard deviation of g per month
  mutate(month = factor(month.abb[month], levels = month.abb)) %>% 
  mutate(col = ifelse(gmean < 0.20, 1, ifelse(gmean < 0.50, 2, ifelse(gmean < 0.80, 3, 4)))) # setting colors for plots based on g value


############## Juvenile mass ###########################

# calculating deviance values in the reference runs
juvMassRef <- juvenileMassOutputs %>%
  group_by(runNumber, month) %>%
  filter(sourceLevel == 0) %>%
  mutate(juvMass = juvMass - juvMass[1],                  # standarizing by setting start to zero  
         juvMassRef = juvMassRef - juvMassRef[1],
         diff = juvMass - juvMassRef) %>%
  filter(diff == min(diff, na.rm = TRUE))                 # finding the largest drop in juvenile mass

# calculating the mean and standard deviation of deviation values per month
maxDevjuvMassRef <- juvMassRef %>%
  ungroup() %>%
  select(runNumber, diff, month) %>%
  group_by(month) %>%
  summarise(meanRef = mean(diff), sdRef = sd(diff)) 

# calculating deviance values in the exposure runs
juvMassExp <- juvenileMassOutputs %>%
  group_by(runNumber, month) %>%
  filter(sourceLevel != 0) %>%
  mutate(juvMass = juvMass - juvMass[1],                   # standarizing by setting start to zero  
         juvMassRef = juvMassRef - juvMassRef[1],
         diff = juvMass - juvMassRef) %>%
  filter(diff == min(diff, na.rm = TRUE)) %>%              # finding the largest drop in juvenile mass
  mutate(group = ifelse(runNumber <= 20, 1, ifelse(runNumber <= 40, 2, ifelse(runNumber <= 60, 3, ifelse(runNumber <= 80, 4, 5))))) # setting colors for plots based on g value

# calculating the mean and standard deviation of deviation values per month
maxDevjuvMassExp <- juvMassExp %>%
  ungroup() %>%
  select(runNumber, diff, group,  month) %>%
  group_by(group, month) %>%
  summarise(mean = mean(diff), sd = sd(diff))

# join for Hedge's calculation
totjuvMass <- left_join(maxDevjuvMassExp, maxDevjuvMassRef, by = c("month"))

hedgesjuvMass <- totjuvMass %>%
  ungroup() %>% 
  group_by(month) %>% 
  mutate(SDpool = sqrt((((100-1)*sdRef^2) + ((20-1)*sd^2))/(100+20-2))) %>%  # pooled standard deviation
  mutate(g = ((meanRef - mean)/SDpool)*(1-(3/(4*(100+20)-9)))) %>%           # hedge's g
  summarise(gmean = mean(g), gsd = sd(g)) %>%                                # average and standard deviation of g per month
  mutate(month = factor(month.abb[month], levels = month.abb)) %>% 
  mutate(col = ifelse(gmean < 0.20, 1, ifelse(gmean < 0.50, 2, ifelse(gmean < 0.80, 3, 4)))) # setting colors for plots based on g value


############## Average effect ###########################

# gathering all results
averageEffect <- bind_rows(
  hedgesLocalAbundance,
  hedgesStorageLevel,
  hedgesTotalCalfLoss,
  hedgesCalfMass,
  hedgesjuvMass)

averageEffect <- averageEffect %>% 
  select(-gsd) %>% 
  group_by(month) %>% 
  summarise(mean = mean(gmean), sd = sd(gmean)) %>%                                       # average of all Hedge's g values per month
  mutate(col = ifelse(mean < 0.20, 1, ifelse(mean < 0.50, 2, ifelse(mean < 0.80, 3, 4)))) # setting colors for plots based on g value

################ Create plots ######################

# plot: local abundance 
pal1 <- wes_palette("Zissou1", 20, type = "continuous") # pull colors from wes anderson palette
pals <- c(pal1[4],pal1[7],pal1[12],pal1[17])

ggplot(hedgesLocalAbundance, aes(x =  (month), fill = as.factor(col))) +
  geom_col(aes(y = gmean),position = "dodge", width = 0.8) +
  geom_linerange(aes(ymin = gmean, ymax = gmean+gsd),position = position_dodge(width = 0.9), col = "grey40", size = 1.0) + 
  geom_hline(yintercept = 0, size = 1.75, col = "grey40") + 
  geom_hline(yintercept = 0.2, col = "grey40", linetype = "dotted", size = 0.9) + 
  geom_hline(yintercept = 0.5, col = "grey40", linetype = "dashed", size = 0.9) + 
  geom_hline(yintercept = 0.8, col = "grey40", linetype = "longdash", size=0.9) + 
  scale_fill_manual(values=pals, guide = F) +
  theme_classic() + 
  labs(title = "Local abundance", x = NULL, y = expression(bold(paste("Hedges' ",bolditalic("g")," effect size"))), fill = NULL)+
  theme(strip.background = element_blank(),
        legend.position = c(0.15, 0.8),
        legend.background = element_blank(),
        strip.text.y = element_text(size = 13, color = "gray40", face = "bold"),
        axis.title = element_text(size = 10, color = "gray40", face = "bold"),
        plot.title = element_text(size = 14, color = "gray40", face = "bold",hjust = 0.5),
        legend.title = element_blank(),
        legend.text = element_text(size = 9, color = "gray40", face = "bold"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))


# plot: storage level 
pal1 <- wes_palette("Zissou1", 20, type = "continuous") # pull colors from wes anderson palette
pals <- c(pal1[7],pal1[12],pal1[17])

ggplot(hedgesStorageLevel, aes(x = (month), fill = as.factor(col))) +
  geom_col(aes(y = gmean),position = "dodge", width = 0.8) +
  geom_linerange(aes(ymin = gmean, ymax = gmean+gsd),position = position_dodge(width = 0.9), col = "grey40", size = 1.0) + 
  geom_hline(yintercept = 0, size = 1.75, col = "grey40") + 
  geom_hline(yintercept = 0.2, col = "grey40", linetype = "dotted", size = 0.9) + 
  geom_hline(yintercept = 0.5, col = "grey40", linetype = "dashed", size = 0.9) + 
  geom_hline(yintercept = 0.8, col = "grey40", linetype = "longdash", size=0.9) + 
  scale_fill_manual(values=pals, guide = F) +
  theme_classic() + 
  labs(title = "Average storage level", x = NULL, y = expression(bold(paste("Hedges' ",bolditalic("g")," effect size"))), fill = NULL)+
  theme(strip.background = element_blank(),
        legend.position = c(0.15, 0.8),
        legend.background = element_blank(),
        strip.text.y = element_text(size = 13, color = "gray40", face = "bold"),
        axis.title = element_text(size = 10, color = "gray40", face = "bold"),
        plot.title = element_text(size = 14, color = "gray40", face = "bold",hjust = 0.5),
        legend.title = element_blank(),
        legend.text = element_text(size = 9, color = "gray40", face = "bold"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))

# plot: total calf loss
pal1 <- wes_palette("Zissou1", 20, type = "continuous") # pull colors from wes anderson palette
pals <- c(pal1[4],pal1[7],pal1[12],pal1[17])

ggplot(hedgesTotalCalfLoss, aes(x = (month), fill = as.factor(col))) +
  geom_col(aes(y = gmean),position = "dodge", width = 0.8) +
  geom_linerange(aes(ymin = gmean, ymax = ifelse(gmean > 0 , gmean+gsd, gmean-gsd)),position = position_dodge(width = 0.9), col = "grey40", size = 1.0) + 
  geom_hline(yintercept = 0, size = 1.75, col = "grey40") + 
  geom_hline(yintercept = 0.2, col = "grey40", linetype = "dotted", size = 0.9) + 
  geom_hline(yintercept = 0.5, col = "grey40", linetype = "dashed", size = 0.9) + 
  geom_hline(yintercept = 0.8, col = "grey40", linetype = "longdash", size=0.9) + 
  scale_fill_manual(values=pals, guide = F) +
  theme_classic() + 
  # coord_flip() + 
  labs(title = "Total calf loss",x = NULL, y = expression(bold(paste("Hedges' ",bolditalic("g")," effect size"))), fill = NULL)+
  theme(strip.background = element_blank(),
        legend.position = c(0.15, 0.8),
        legend.background = element_blank(),
        plot.title = element_text(size = 14, color = "gray40", face = "bold",hjust = 0.5),
        strip.text.y = element_text(size = 13, color = "gray40", face = "bold"),
        axis.title = element_text(size = 10, color = "gray40", face = "bold"),
        legend.title = element_blank(),
        legend.text = element_text(size = 9, color = "gray40", face = "bold"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))

# plot: calf mass
pal1 <- wes_palette("Zissou1", 20, type = "continuous") # pull colors from wes anderson palette
pals <- c(pal1[4],pal1[12],pal1[17])

ggplot(hedgesCalfMass, aes(x = (month), fill = as.factor(col))) +
  geom_col(aes(y = gmean),position = "dodge", width = 0.8) +
  geom_linerange(aes(ymin = gmean, ymax = ifelse(gmean > 0 , gmean+gsd, gmean-gsd)),position = position_dodge(width = 0.9), col = "grey40", size = 1.0) +
  geom_hline(yintercept = 0, size = 1.75, col = "grey40") +
  geom_hline(yintercept = 0.2, col = "grey40", linetype = "dotted", size = 0.9) +
  geom_hline(yintercept = 0.5, col = "grey40", linetype = "dashed", size = 0.9) +
  geom_hline(yintercept = 0.8, col = "grey40", linetype = "longdash", size=0.9) +
  scale_fill_manual(values=pals, guide = F) +
  theme_classic() +
  labs(title = "Calf mass", x = NULL, y = expression(bold(paste("Hedges' ",bolditalic("g")," effect size"))), fill = NULL)+
  theme(strip.background = element_blank(),
        legend.position = c(0.15, 0.8),
        legend.background = element_blank(),
        strip.text.y = element_text(size = 13, color = "gray40", face = "bold"),
        plot.title = element_text(size = 14, color = "gray40", face = "bold",hjust = 0.5),
        axis.title = element_text(size = 10, color = "gray40", face = "bold"),
        legend.title = element_blank(),
        legend.text = element_text(size = 9, color = "gray40", face = "bold"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))


# plot: juvenile mass 
pal1 <- wes_palette("Zissou1", 20, type = "continuous") # pull colors from wes anderson palette
pals <- c(pal1[7],pal1[12],pal1[17])

ggplot(hedgesjuvMass, aes(x = (month), fill = as.factor(col))) +
  geom_col(aes(y = gmean),position = "dodge", width = 0.8) +
  geom_linerange(aes(ymin = gmean, ymax = gmean+gsd),position = position_dodge(width = 0.9), col = "grey40", size = 1.0) + 
  geom_hline(yintercept = 0, size = 1.75, col = "grey40") + 
  geom_hline(yintercept = 0.2, col = "grey40", linetype = "dotted", size = 0.9) + 
  geom_hline(yintercept = 0.5, col = "grey40", linetype = "dashed", size = 0.9) + 
  geom_hline(yintercept = 0.8, col = "grey40", linetype = "longdash", size=0.9) + 
  scale_fill_manual(values=pals, guide = F) +
  theme_classic() + 
  #coord_flip() + 
  labs(title = "Juvenile mass",x = NULL, y = expression(bold(paste("Hedges' ",bolditalic("g")," effect size"))), fill = NULL)+
  theme(strip.background = element_blank(),
        legend.position = c(0.15, 0.8),
        legend.background = element_blank(),
        strip.text.y = element_text(size = 13, color = "gray40", face = "bold"),
        axis.title = element_text(size = 10, color = "gray40", face = "bold"),
        plot.title = element_text(size = 14, color = "gray40", face = "bold",hjust = 0.5),
        legend.title = element_blank(),
        legend.text = element_text(size = 9, color = "gray40", face = "bold"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))

# plot: average effect
ggplot(averageEffect, aes(x = month, fill = as.factor(col))) +
  geom_col(aes(y = mean),position = "dodge", width = 0.8) +
  geom_linerange(aes(ymin = mean, ymax = mean+sd),position = position_dodge(width = 0.9), col = "grey40", size = 1.0) + 
  geom_hline(yintercept = 0, size = 1.75, col = "grey40") + 
  geom_hline(yintercept = 0.2, col = "grey40", linetype = "dotted", size = 0.9) + 
  geom_hline(yintercept = 0.5, col = "grey40", linetype = "dashed", size = 0.9) + 
  geom_hline(yintercept = 0.8, col = "grey40", linetype = "longdash", size=0.9) + 
  scale_fill_manual(values=pals, guide = F) +
  theme_classic() + 
  labs(dtitle = "Summary",x = NULL, y = expression(bold(paste("Hedges' ",bolditalic("g")," effect size"))), fill = NULL)+
  theme(strip.background = element_blank(),
        legend.position = c(0.15, 0.8),
        legend.background = element_blank(),
        strip.text.y = element_text(size = 13, color = "gray40", face = "bold"),
        axis.title = element_text(size = 10, color = "gray40", face = "bold"),
        plot.title = element_text(size = 14, color = "gray40", face = "bold",hjust = 0.5),
        legend.title = element_blank(),
        legend.text = element_text(size = 9, color = "gray40", face = "bold"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))


