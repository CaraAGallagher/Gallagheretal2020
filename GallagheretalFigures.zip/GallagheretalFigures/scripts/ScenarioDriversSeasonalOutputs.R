# Cara Gallagher
# updated April 19th, 2020
# Porpoise Energy Budget scenario environmental and physioloigcal drivers
# All drivers recorded daily within 40km of a survey ship
# Figure 4 in Gallagher et al. (submitted)
# See main text for details

library(tidyverse)
library(wesanderson)

############### Read in driver data ###############

# water temperature data
tempDat <- read_csv("data/DriversSeasonalWaterTemp.csv")

# data for the other three recorded drivers
allDat <- read_csv("data/DriversSeasonalOutputsSLEBCP.csv")      

# Storage levels
SLDat <- allDat %>% 
  filter(metric == "StorageLevels") %>% 
  group_by(month) %>% 
  summarise(mean = mean(val), sd = sd(val))

# Energy balance - energy in / energy out
EBDat <- allDat %>% 
  filter(metric == "EnergyBalance") %>% 
  group_by(month) %>% 
  summarise(mean = mean(val), sd = sd(val))

# Local abundance - count porpoise agents (superindividuals)
CPDat <- allDat %>% 
  filter(metric == "CountPorps") %>% 
  group_by(month) %>% 
  summarise(mean = mean(val), sd = sd(val)) 

################ Create plots ######################

pal <- wes_palette("Zissou1", 5, type = "continuous") # pull colors from wes anderson palette

# plot: seasonal water temperature
ggplot(tempDat, aes(x = month, y = mean, group = 1)) + 
  geom_line(size = 1.75, col = "grey40") + 
  geom_point(col = "white", size = 8, shape = 19) +
  geom_linerange(aes(ymin = mean - sd, ymax = mean + sd), col = pal[1], size = 1.5, alpha = 0.5) +
  geom_point(fill = pal[1],col = "grey40", size = 3, shape = 21, stroke = 1.5) +
  theme_classic() + 
  labs(x = "Month", y = "Water temperature [C]", col = NULL)+
  scale_x_continuous(breaks = c(1:12)) +
  theme(strip.background = element_blank(),
        legend.background = element_blank(),
        strip.text.y = element_text(size = 13, color = "gray40", face = "bold"),
        axis.title = element_text(size = 10, color = "gray40", face = "bold"),
        legend.title = element_text(size = 13, color = "gray40", face = "bold"),
        legend.text = element_text(size = 10, color = "gray40", face = "bold"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))

# plot: seasonal storage level 
ggplot(SLDat, aes(x = month, y = mean, group = 1)) + 
  geom_line(size = 1.75, col = "grey40") + 
  geom_point(col = "white", size = 8, shape = 19) +
  geom_linerange(aes(ymin = mean - sd, ymax = mean + sd), col = pal[1], size = 1.5, alpha = 0.5) +
  geom_point(fill = pal[1],col = "grey40", size = 3, shape = 21, stroke = 1.5) +
  theme_classic() + 
  labs(x = "Month", y = "Storage levels [%]", col = NULL)+
  scale_x_continuous(breaks = c(1:12)) +
  theme(strip.background = element_blank(),
        legend.background = element_blank(),
        strip.text.y = element_text(size = 13, color = "gray40", face = "bold"),
        axis.title = element_text(size = 10, color = "gray40", face = "bold"),
        legend.title = element_text(size = 13, color = "gray40", face = "bold"),
        legend.text = element_text(size = 10, color = "gray40", face = "bold"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))

# plot: seasonal energy balance 
ggplot(EBDat, aes(x = month, y = mean, group = 1)) + 
  geom_hline(yintercept = 1, size = 1.0, col = "grey40") +
  geom_line(size = 1.75, col = "grey40") + 
  geom_point(col = "white", size = 8, shape = 19) +
  geom_linerange(aes(ymin = mean - sd, ymax = mean + sd), col = pal[1], size = 1.5, alpha = 0.5) +
  geom_point(fill = pal[1],col = "grey40", size = 3, shape = 21, stroke = 1.5) +
  theme_classic() + 
  labs(x = "Month", y = "Energy balance", col = NULL)+
  scale_x_continuous(breaks = c(1:12)) +
  theme(strip.background = element_blank(),
        legend.background = element_blank(),
        strip.text.y = element_text(size = 13, color = "gray40", face = "bold"),
        axis.title = element_text(size = 10, color = "gray40", face = "bold"),
        legend.title = element_text(size = 13, color = "gray40", face = "bold"),
        legend.text = element_text(size = 10, color = "gray40", face = "bold"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))

# plot: seasonal local abundance
CPDat$month <- factor(month.abb[CPDat$month],levels=month.abb)
ggplot(CPDat, aes(x = month, y = mean, group = 1)) + 
  geom_line(size = 1.75, col = "grey40") + 
  geom_point(col = "white", size = 8, shape = 19) +
  geom_linerange(aes(ymin = mean - sd, ymax = mean + sd), col = pal[1], size = 1.5, alpha = 0.5) +
  geom_point(fill = pal[1],col = "grey40", size = 3, shape = 21, stroke = 1.5) +
  theme_classic() + 
  labs(x = "Month", y = "Number of porpoises [N]", col = NULL)+
  theme(strip.background = element_blank(),
        legend.background = element_blank(),
        strip.text.y = element_text(size = 13, color = "gray40", face = "bold"),
        axis.title = element_text(size = 10, color = "gray40", face = "bold"),
        legend.title = element_text(size = 13, color = "gray40", face = "bold"),
        legend.text = element_text(size = 10, color = "gray40", face = "bold"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9))

