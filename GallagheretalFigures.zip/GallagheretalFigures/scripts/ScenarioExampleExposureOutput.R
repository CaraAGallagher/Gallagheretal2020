# Cara Gallagher
# updated April 19th, 2020
# Porpoise Energy Budget scenario example exposure output
# Figure 5 in Gallagher et al. (submitted)
# See main text for details

library(tidyverse)
library(bcpa)
library(raster)
library(wesanderson)
library(ggspatial)
library(broom)

############## MSSL example output plots #############

# Mass (both total and structural), reproductive state, and sound level received by a porpoise in an exposure scenario occuring in September

MSSL <- read_csv("data/ScenarioExampleOutputPorpoiseMSSL.csv") # load tracked porpoise mass, state, and sound levels

# grab plot colors
pal <- wes_palette("Zissou1", 12, type = "continuous") 
pal <- c(pal[1],pal[5],pal[7],pal[10],pal[12])

palRL <- wes_palette("Zissou1", 5, type = "continuous")
palRL <- palRL[4]

# Legend was made separately due to ggplot trickiness 
legendCol <- tibble(
  stat = c("Structural mass", "Immature", "Mature non-reproductive", "Pregnant","Lactating", "Pregnant and lactating"),
  TS = c(0,0,0,0,0,0),
  test = c(50,50,50,50,50,50)
)
legcol <- c("grey40",pal)
legendCol$stat <- factor(legendCol$stat, levels = c("Structural mass", "Immature", "Mature non-reproductive", "Pregnant","Lactating", "Pregnant and lactating"))

# plot: adult porpoise's mass and reproductive state
ggplot() + 
  geom_line(data = MSSL, aes(x = TS, y = dailyMassStructList), col = "grey40", size = 1.05) +
  geom_line(data = MSSL, aes(x = TS, y = dailyMassList), col = "grey40", size = 1.05) + 
  geom_line(data = MSSL, aes(x = TS, y = dailyMassList, col = as.factor(reproductiveStatusList), group=1), size = 1.05) + 
  geom_point(data = legendCol, aes(x = TS, y = test, fill = factor(stat)), shape=22, col = NA, alpha = 0) +
  scale_color_manual(values = pal,guide=FALSE) +
  scale_fill_manual(values = legcol, name="") +
  theme_classic()+ 
  labs(x = "Years since start of disturbance", y = "Female mass [kg]") +
  ylim(15,70) +
  scale_x_continuous(breaks = seq(-9, 2, 1)) +
  guides(fill = guide_legend(override.aes = list(shape = "-", col = legcol, size=5, stroke = 6, alpha = 1))) +
  theme(axis.title = element_text(size = 9, color = "gray40", face = "bold"),
        axis.text = element_text(size = 8, color = "gray40", face = "bold"),
        legend.key.width = unit(0.25,"cm"), 
        legend.key.height = unit(0.25,"cm"),
        legend.position = c(0.85, 0.275),
        legend.text = element_text(size = 11, color = "gray40"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9),
        panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
        panel.grid.major = element_line(colour = "gray90",size=0.5),
        panel.grid.major.y = element_blank())

# plot: mass of the adult porpoise's calves
ggplot(MSSL, aes(x = TS)) +   
  geom_line(aes(y = dailyMassCalfList), col = pal[1], size = 1.05) +
  geom_line(aes(y = dailyMassStructCalfList), col = "grey40", size = 1.05) +
  theme_classic()+ 
  labs(x = "Years since start of disturbance", y = "Calf mass [kg]") +
  scale_x_continuous(breaks = seq(-9, 2, 1)) +
  theme(axis.title = element_text(size = 9, color = "gray40", face = "bold"),
        axis.text = element_text(size = 8, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9),
        panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
        panel.grid.major = element_line(colour = "gray90",size=0.5),
        panel.grid.major.y = element_blank())

## plot: porpoise's received level
ggplot(MSSL, aes(x = TS)) +   
  geom_ribbon(aes(ymin = 0, ymax = receivedLevelList), fill = "grey25") +
  geom_line(aes(y = 0), col = "grey25", size = 0.5) +
  theme_classic()+ 
  labs(x = "Years since start of disturbance", y = expression(bold(paste("RL [dB re 1 ", mu, "Pa]")))) +
  scale_x_continuous(breaks = seq(-9, 2, 1)) +
  theme(axis.title = element_text(size = 9, color = "gray40", face = "bold"),
        axis.text = element_text(size = 8, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9),
        panel.border = element_rect(colour = "gray40", fill=NA, size=0.9),
        panel.grid.major = element_line(colour = "gray90",size=0.5),
        panel.grid.major.y = element_blank())

############## Movement track output #############

porpTrack <- read_csv("data/ScenarioExampleOutputPorpoiseTrack.csv") # import track data for exposure period

# pull and process maxent data for the quarter
maxEntASCII <- raster("data/quarter4.asc")
bb <- extent(0, 599, 0, 999)
extent(maxEntASCII) <- bb
# clip extent to around porpoise track
b1 <- as(extent((min(porpTrack$posX) - 25), (max(porpTrack$posX) + 25), (min(porpTrack$posY) - 5), (max(porpTrack$posY) + 5)), 'SpatialPolygons')
maxEntASCII <- crop(maxEntASCII, b1)
# convert to points and then a tibble
mapP <- rasterToPoints(maxEntASCII)
mapTib <- as_tibble(data.frame(mapP))
colnames(mapTib) <- c("X", "Y", "MaxEnt")

colfunc <- colorRampPalette(c("white", pal[1]))

# plot: focal follow movement path
ggplot() +
  geom_raster(data = mapTib , aes(x = mapTib$X, y = mapTib$Y, fill = mapTib$MaxEnt)) +
  theme_classic() +
  theme(panel.background = element_rect(fill = 'grey95'))+
  coord_equal(expand=FALSE) +
  geom_path(data = porpTrack, aes(x = porpTrack$posX, y = porpTrack$posY), col ="gray20", size = 1)+
  geom_point(data = porpTrack, aes(x = porpTrack$posX, y = porpTrack$posY), col = "gray20", size = 5) +
  geom_point(data = porpTrack, aes(x = porpTrack$posX, y = porpTrack$posY, col = as.factor(porpTrack$color)), size = 3) +
  scale_fill_gradientn(limits = c(0.00, 0.85), colours =  c("#FFFFFF",colfunc(5), "#13333B"), guide=FALSE, values = c(0.0,0.3,0.4,0.5,0.7,0.75,1)) +
  scale_color_manual(values = c("green", "black", "yellow", "red"), labels = c("Track start", "RL <= T", "RL > T", "Track end"),
                     guide = guide_legend(override.aes = list(shape = 21, col = "grey20", fill = c("green", "black", "yellow", "red"),stroke = 2))) +
  labs(x = "X", y = "Y", col = NULL) +
  theme(axis.title = element_blank(),
        legend.background = element_rect(fill = NA),
        legend.text = element_text(color ="gray30", size=10, margin = margin(l = -3), hjust = 0, face = "bold"),
        axis.text = element_blank(),
        axis.ticks = element_blank(),
        axis.line = element_blank(),
        plot.margin=unit(c(0.25,-0.5,0.25,0),"cm"),
        panel.border = element_rect(colour = "gray30", fill=NA, size=1)) 

# import survey routes
OmoTrack <- read_csv("data/ShipTracks/OmoTrack.csv", col_names = TRUE)
SBTrack <- read_csv2("data/ShipTracks/SBTrack.csv", col_names = TRUE)
SamsoTrack <- read_csv2("data/ShipTracks/SamsoTrack.csv", col_names = TRUE)

# pull maxent data for quarter
maxEntASCIIAll <- raster("data/quarter4.asc")
bb <- extent(0, 599, 0, 999)
extent(maxEntASCIIAll) <- bb
b <- extent(50, 500, 275, 630)
maxEntASCIIAll <- crop(maxEntASCIIAll, b)

mapAll <- rasterToPoints(maxEntASCIIAll)
mapAll <- as_tibble(data.frame(mapAll))
colnames(mapAll) <- c("X", "Y", "MaxEnt")

tidyb1 <- tidy(b1)

# plot: map area with survey tracks for reference
ggplot() +
  geom_raster(data = mapAll , aes(x = mapAll$X, y = mapAll$Y, fill = MaxEnt)) +
  theme_classic() +
  theme(panel.background = element_rect(fill = 'grey95'))+
  coord_equal(expand=FALSE) +
  geom_path(data = OmoTrack, aes(x = OmoTrack$posX, y = OmoTrack$posY), size = 0.25, col ="black")+
  geom_path(data = SBTrack, aes(x = SBTrack$posX, y = SBTrack$posY), size = 0.25, col ="black")+
  geom_path(data = SamsoTrack, aes(x = SamsoTrack$posX, y = SamsoTrack$posY), size = 0.25, col ="black")+
  annotate("rect",xmin = tidyb1$long[1], xmax = tidyb1$long[3], ymin = tidyb1$lat[1], ymax = tidyb1$lat[2], fill=NA, col = "gray40", size = 0.8) +
  scale_fill_gradientn(limits = c(0.00, 0.85), colours =  c("#FFFFFF",colfunc(5), "#12212E"), values = c(0.0,0.3,0.4,0.5,0.7,0.75,1) ,guide = guide_colorbar(title.position = "left", barwidth = 0.75, barheight = 23.75,  frame.linetype = 1, frame.linewidth = 2, frame.colour = "gray30",ticks = FALSE,label.position = "left")) +
  labs(x = NULL, y = NULL, fill = "Food proxy") +
  theme(legend.position = c(1.06,0.503),
        axis.title = element_blank(),
        axis.text = element_blank(),
        legend.background = element_rect(fill = NA),
        legend.title = element_text(color ="gray40", size=12, angle = 90, hjust = 0.5, face = "bold"),
        legend.text = element_text(color ="gray40", size=10, margin = margin(l = -3), hjust = 0, face = "bold"),
        axis.line = element_blank(),
        axis.ticks= element_blank(),
        axis.ticks.length = unit(0, "mm"),
        legend.title.align=0.5,
        panel.border = element_rect(colour = "gray40", fill=NA, size=1))




