# Cara Gallagher
# updated April 19th, 2020
# Porpoise Energy Budget ABC calibration outputs
# Using trends from Otani et al. 2001 and Rojano-Doñate et al. 2018
# Figure 2 in Gallagher et al. (submitted)
# See TRACE section 6 for details

library(tidyverse)
library(wesanderson)

############## Swimming speed-dependant oxygen consumption calibration outputs #############

vO2SwimCalOut <- read_csv("data/CalibrationOtaniOutputs.csv") # 100 best fit outputs

# calibrated parameter check (the ratio of active to passive drag (lambda))
lambdaOut <- vO2SwimCalOut %>% 
  select(lambda) %>% 
  unique()

mean(lambdaOut$lambda) 
sd(lambdaOut$lambda)
hist(lambdaOut$lambda)
shapiro.test(lambdaOut$lambda) # test of normality. p > 0.05 = normally distributed.

# calculate the range of accepted outputs at each swimming speed
vO2SwimMinMax <- vO2SwimCalOut %>% 
  group_by(velocity) %>% 
  summarise(vO2mean = mean(vO2), vO2sd = sd(vO2), vO2hi = max(vO2), vO2lo = min(vO2))

# the emipirical relationship in Otani et al. 2001
empDataOtani <- tibble(velocity = seq(0.1, 1.6, 0.1))
empDataOtani <- empDataOtani %>% 
  mutate(empDatavO2 = (7.97 + 5.10 * velocity - 9.51 * velocity^2 + 4.93 * velocity^3))   

############## Field metabolic rate calibration outputs #############

FMRCalOut <- read_csv("data/CalibrationFMROutputs.csv") # 100 best fit outputs

# calibrated parameter check (the maintenance normalization constant (Bo))
BoOut <- FMRCalOut %>% 
  select(Bo) %>% 
  unique()

mean(BoOut$Bo)
sd(BoOut$Bo)
hist(BoOut$Bo)
shapiro.test(BoOut$Bo) # test of normality. p > 0.05 = normally distributed.

# calculate the range of accepted outputs at each mass
FMRMinMax <- FMRCalOut %>% 
  group_by(mass) %>% 
  summarise(FMRmean = mean(FMR), FMRsd = sd(FMR), FMRhi = max(FMR), FMRlo = min(FMR))

# the emipirical relationship in Rojano-Doñate et al. 2018
empTrendRD <- tibble(mass = seq(26,76,1))
empTrendRD <- empTrendRD %>%  
  mutate(FMR = (0.53 * (mass ^ 0.90)))

# the data points in Rojano-Doñate et al. 2018
empDataRD <- data.frame (
  Mass = c(26,27,31,31,32,34,35,38,41,49,68,68,76,64,56,65),
  FMR  = c(15.3,12.0,7.8,9.3,9.8,12.5,11.1,12.8,15.3,24.6,22.3,17.5,31.0,22.2,22.4,19.6),
  FMRhi = c(NA, 12.8,8.4,9.9,10.9,13.3,12.3,13.6,17.9,26.1,24.4,19.6,34.4,NA,NA,NA),
  FMRlo = c(NA, 11.4,7.3,8.9,9.0,12.0,9.5,12.2,11.8,23.6,20.9,15.1,27.29,NA,NA,NA),
  WildVCap = c(rep("Wild", times = 13), rep("Captive", times = 3))
)


################ Create plots ######################

pal <- wes_palette("Zissou1", 10, type = "continuous") # pull colors from wes anderson palette

# plot: oxygen consumption by swim speed
# emprical in blue, model results in red

ggplot() +
  geom_ribbon(data=vO2SwimMinMax, aes(x = velocity, ymax = vO2hi, ymin = vO2lo), fill = pal[10]) +
  geom_line(data = empDataOtani, aes(x = velocity, y= empDatavO2), size = 1.5, linetype = "dashed", col=pal[1]) +
  theme_classic() +
  labs(x = expression(bold("Velocity [m s"^-1*"]")), y = expression(bold("Oxygen Consumption [ml O"[2]*" kg"^-1*" min"^-1*"]"))) + 
  ylim(5.5,12.5) +
  geom_text(data = data.frame(), aes(x=0.55, y=6, label= "VO[2] == 7.97 + 5.10 * V - 9.51 * V^2 + 4.93*V^3"), fontface = "bold", size = 4, col=pal[1], parse = TRUE,inherit.aes = FALSE) + 
  theme(text = element_text(size = 11, color = "gray40", face = "bold"),
        legend.position = "none",
        plot.margin=unit(c(0.25,0.25,0.25,0.25),"cm"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.title = element_text(size = 12, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9),
        panel.border = element_rect(colour = "gray40", fill=NA, size=0.9))


# plot: field metabolic rate by body mass
# emprical in blue, model results in red

ggplot() +
  geom_ribbon(data=FMRMinMax, aes(x = mass, ymax =  FMRhi, ymin = FMRlo), fill = pal[10]) +
  geom_line(data = empTrendRD, aes(x = mass, y=FMR), size = 1.5, linetype = "dashed", col=pal[1]) +
  theme_classic() +
  geom_point(data= empDataRD, aes(x= Mass, y = FMR, shape = WildVCap), size = 3, col = pal[1], stroke = 1.5) + ylim(5,35) +
  geom_linerange(data= empDataRD, aes(x= Mass, ymin = FMRlo, ymax = FMRhi), col =  pal[1], size = 1) + 
  theme_classic() + 
  scale_shape_manual(values = c(21,19)) +
  labs(y = expression(bold("FMR [MJ day"^-1*"]")), x ="Mass [kg]") +
  geom_text(data = data.frame(), aes(x=32.5, y=5.5, label= "FMR == 0.53 * M^0.9"), size = 4, col=pal[1], parse = TRUE,inherit.aes = FALSE) +
  theme(legend.position = c(0.9, 0.1), 
        legend.title = element_blank(), 
        legend.background = element_rect(color = NA, fill = NA),
        legend.text = element_text(size = 11, color = "gray40", face = "bold"),
        text = element_text(size = 11, color = "gray40", face = "bold"),
        plot.margin=unit(c(0.25,0.25,0.25,0.25),"cm"),
        axis.text = element_text(size = 11, color = "gray40", face = "bold"),
        axis.title = element_text(size = 12, color = "gray40", face = "bold"),
        axis.line = element_line(colour = "gray40", size=0.9),
        axis.ticks= element_line(colour = "gray40", size=0.9),
        panel.border = element_rect(colour = "gray40", fill=NA, size=0.9))
   

